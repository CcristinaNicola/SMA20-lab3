# SMA20-lab1
Laborator 1 SMA
